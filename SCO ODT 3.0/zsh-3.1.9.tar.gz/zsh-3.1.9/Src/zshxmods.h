#define    LINKED_XMOD_zshQsrlimits 1
#define    LINKED_XMOD_zshQszle 1
#define    LINKED_XMOD_zshQscomplete 1
#define    LINKED_XMOD_zshQscompctl 1
#define    LINKED_XMOD_zshQssched 1
#define    LINKED_XMOD_zshQscomplist 1
#define    LINKED_XMOD_zshQszutil 1
#define    LINKED_XMOD_zshQscomputil 1
#define    LINKED_XMOD_zshQsparameter 1
#define    LINKED_XMOD_zshQszleparameter 1
#ifdef DYNAMIC
# define UNLINKED_XMOD_cap 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_clone 1
#endif
#define    LINKED_XMOD_compctl 1
#define    LINKED_XMOD_complete 1
#define    LINKED_XMOD_complist 1
#define    LINKED_XMOD_computil 1
#ifdef DYNAMIC
# define UNLINKED_XMOD_deltochar 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_example 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_files 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_mapfile 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_mathfunc 1
#endif
#define    LINKED_XMOD_parameter 1
#define    LINKED_XMOD_rlimits 1
#define    LINKED_XMOD_sched 1
#ifdef DYNAMIC
# define UNLINKED_XMOD_stat 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_zftp 1
#endif
#define    LINKED_XMOD_zle 1
#define    LINKED_XMOD_zleparameter 1
#define    LINKED_XMOD_zutil 1
