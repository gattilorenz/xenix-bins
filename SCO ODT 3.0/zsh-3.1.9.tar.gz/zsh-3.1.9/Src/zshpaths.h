#define MODULE_DIR "/usr/local/lib/zsh/3.1.9"
#define SITEFPATH_DIR "/usr/local/share/zsh/site-functions"
#define FPATH_DIR "/usr/local/share/zsh/3.1.9/functions"
