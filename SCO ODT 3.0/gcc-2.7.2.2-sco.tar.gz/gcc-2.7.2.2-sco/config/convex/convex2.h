/* tm.h file for a Convex C2.  */

#define TARGET_DEFAULT 002

#include "convex/convex.h"
