#include "mips/xm-mips.h"
#include "config/xm-netbsd.h"
