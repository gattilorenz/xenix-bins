/*
 * fundamental variables
 */

#ifndef FFS
#define FFS
#endif

/*
 * filesystem parameters
 */

#define	SUPERB	((daddr_t)1)	/* block number of the super block */
#define	DIRSIZ	14		/* max characters per directory */
#define	NICINOD	100		/* number of superblock inodes */
#define	NICFREE	50		/* number of superblock free blocks */
#define	S5ROOTINO	2	/* i number of all roots */

#ifndef FsTYPE
#define FsTYPE	2
#endif

#if FsTYPE==1
/* Original 512 byte file system */
#define	BSIZE		512		/* size of secondary block (bytes) */
#define SBUFSIZE	512		/* system buffer size */
#define	BSHIFT		9		/* log2(BSIZE) */
#define	NINDIR		(BSIZE/sizeof(daddr_t))	/* BSIZE/sizeof(daddr_t) */
#define	BMASK		0777		/* BSIZE-1 */
#define INOPB		8		/* BSIZE/sizeof(struct dinode) */
#define INOSHIFT	3		/* log2(INOPB) */
#define	NMASK		0177		/* NINDIR-1 */
#define	NSHIFT		7		/* log2(NINDIR) */
#define NDPC		4		/* number of blocks/click */
#define Fs2BLK		0x8000		/* large block flag in bsize */
#endif

#if FsTYPE==2
/* New 1024 byte file system */
#define	BSIZE		1024		/* size of secondary block (bytes) */
#define SBUFSIZE	1024		/* system buffer size */
#define	BSHIFT		10		/* log2(BSIZE) */
#define	NINDIR		(BSIZE/sizeof(daddr_t))	/* BSIZE/sizeof(daddr_t) */
#define	BMASK		01777		/* BSIZE-1 */
#define INOPB		16		/* BSIZE/sizeof(struct dinode) */
#define INOSHIFT	4		/* log2(INOPB) */
#define	NMASK		0377		/* NINDIR-1 */
#define	NSHIFT		8		/* log2(NINDIR) */
#define NDPC		4		/* number of blocks per click */
#define Fs2BLK		0x8000		/* large block flag in bsize */
#endif

#if FsTYPE==3
/* Dual file system */
#define	BSIZE		512		/* size of secondary block (bytes) */
#define SBUFSIZE	1024		/* system buffer size */
#define	BSHIFT		9		/* log2(BSIZE) */
#define	NINDIR		128		/* BSIZE/sizeof(daddr_t) */
#define	BMASK		0777		/* BSIZE-1 */
#define INOPB		8		/* BSIZE/sizeof(struct dinode) */
#define INOSHIFT	3		/* log2(INOPB) */
#define	NMASK		0177		/* NINDIR-1 */
#define	NSHIFT		7		/* log2(NINDIR) */
#define NDPC		4
#define Fs2BLK		0x8000		/* large block flag in bsize */
#endif

#if FsTYPE==4
/* New 2048 byte file system */
#define	BSIZE		2048		/* size of secondary block (bytes) */
#define SBUFSIZE	2048		/* system buffer size */
#define	BSHIFT		11		/* log2(BSIZE) */
#define	NINDIR		(BSIZE/sizeof(daddr_t))	/* BSIZE/sizeof(daddr_t) */
#define	BMASK		03777		/* BSIZE-1 */
#define INOPB		32		/* BSIZE/sizeof(struct dinode) */
#define INOSHIFT	5		/* log2(INOPB) */
#define	NMASK		0777		/* NINDIR-1 */
#define	NSHIFT		9		/* log2(NINDIR) */
#define NDPC		4		/* number of blocks per click */
#define Fs2BLK		0x8000		/* large block flag in bsize */
#endif

#define SUPERBOFF	512	/* superblock offset */

#ifdef FFS
/*
 * Fast File System Parameters
 */
#define	FsBNO(dev, x)	(((x) >> BSHIFT))
#define	FsBOFF(dev, x)	(((x) & BMASK))
#define FsFPB(dev)	(BSIZE*8) /* Bits per block */

/* Maximum clustering factor for disk reads */
#define NBCLUSTER 16	

#endif /* FFS */

#define	MAXPID	30000		/* max process id */
#define	MAXUID	60000		/* max user id */
#define	MAXLINK	1000		/* max links */

#define	SSIZE	1		/* initial stack size (*4096 bytes) */
#define	SINCR	1		/* increment of stack (*4096 bytes) */
#define	USIZE	MINUSIZE	/* initial size of user block (*4096 bytes) */
#define	MINUSIZE  2		/* min size of user block (*4096 bytes) */
#define	MAXUSIZE 18		/* max size of user block (*4096 bytes) */

#define	CANBSIZ	256		/* max size of typewriter line	*/
#define	HZ	60		/* 60 ticks/second of the clock */

#define	NCARGS	5120		/* # characters in exec arglist */
				/*   must be multiple of NBPW.  */

/*	The following define is here for temporary compatibility
**	and should be removed in the next release.  It gives a
**	value for the maximum number of open files per process.
**	However, this value is no longer a constant.  It is a
**	configurable parameter, NOFILES, specified in the kernel
**	master file and available in v.v_nofiles.  Programs which
**	include this header file and use the following value may
**	not operate correctly if the system has been configured
**	to a different value.
*/

#define	NOFILE	60

/*	The following represent the minimum and maximum values to
**	which the paramater NOFILES in the kernel master file may
**	be set.
*/

#define	NOFILES_MIN	 20
#define	NOFILES_MAX	100

/*	The following represents the maximum value to which
**	the parameter NGROUPS in the kernel master file may be set.
**
**	New for POSIX
*/

#define NGROUPS_MAXTUNE	16

#ifndef NULLGROUP
#define NULLGROUP	((gid_t) 65535)
#endif

/*	The following defines apply to the kernel virtual
**	address space.
*/

#define	SYSSEGSZ 1024	/* The size of the kernel segment	*/
			/* sysseg in pages.  The starting	*/
			/* address comes from the vuifile.	*/

#define	MAXKSEG		127	/* max no of pages per kseg */

/*	To avoid prefetch errors at the end of a region, it must
**	be padded with the following number of bytes.
*/

#define	PREFETCH	0

/*
 * priorities
 * should not be altered too much
 */

#define	PMASK	0177
#define	PCATCH	0400
#define	PNOSTOP	01000
#define	PSWP	0
#define	PINOD	10
#define	PRIBIO	20
#define	PZERO	25
#define PMEM	0
#define	NZERO	20
#define	PPIPE	26
#define	PWAIT	30
#define	PSLEP	39
#define	PUSER	60
#define	PIDLE	127

/*
 * Priority for tracing (ptrace and paccess)
 */

#define	IPCPRI	PZERO

/*
 * fundamental constants of the implementation--
 * cannot be changed easily
 */

#define	NBPW	sizeof(int)	/* number of bytes in an integer */
#define	NCPPT	1024		/* Number of clicks per page table */
#define	CPPTSHIFT	10	/* LOG2(NCPPT) if exact */
#define	NBPC	4096		/* Number of bytes per click */
#define	BPCSHIFT	12	/* LOG2(NBPC) if exact */

#ifndef NULL
#define	NULL	0
#endif

#define	CDLIMIT	(1L<<14)	/* default max write address */
#define	NODEV	(dev_t)(-1)
#define NBPSCTR         512     /* Bytes per LOGICAL disk sector. */
#define SCTRSHFT        9       /* Shift for BPSECT.            */

#define	UMODE	3		/* current Xlevel == user */
#define	USERMODE(cs)	(((cs) & SEL_RPL) == UMODE)

#define	lobyte(X)	(((unsigned char *)&X)[0])
#define	hibyte(X)	(((unsigned char *)&X)[1])
#define	loword(X)	(((u_short *)&X)[0])
#define	hiword(X)	(((u_short *)&X)[1])

#define	MAXSUSE	255

/* REMOTE -- whether machine is primary, secondary, or regular */
#define SYSNAME 9		/* # chars in system name */
#define PREMOTE 39

/* XENIX compatibility */
#define	ktop(vaddr)	((paddr_t)svirtophys(vaddr))
#define ptok(vaddr) 	(phystokv(vaddr))

/* Maxmimum pathsize acceptable to namei */

#if MINUSIZE == 2 && NBPC < 4096
#define PATHSIZE	512
#else
#define PATHSIZE	1024
#endif
