#include <gnu-stabs.h>

#undef	mach_msg_destroy
symbol_alias (__mach_msg_destroy, mach_msg_destroy);
