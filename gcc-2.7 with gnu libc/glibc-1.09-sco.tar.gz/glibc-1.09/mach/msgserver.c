#include <gnu-stabs.h>

#undef	mach_msg_server
symbol_alias (__mach_msg_server, mach_msg_server);
