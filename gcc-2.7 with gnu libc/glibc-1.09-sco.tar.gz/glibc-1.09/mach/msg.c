#include <gnu-stabs.h>

symbol_alias (__mach_msg, mach_msg);
symbol_alias (__mach_msg_send, mach_msg_send);
symbol_alias (__mach_msg_receive, mach_msg_receive);
