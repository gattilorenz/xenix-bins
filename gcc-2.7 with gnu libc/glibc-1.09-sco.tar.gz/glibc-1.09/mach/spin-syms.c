#include <gnu-stabs.h>

symbol_alias (__spin_lock_init, spin_lock_init);
symbol_alias (__spin_lock_solid, spin_lock_solid);
symbol_alias (__spin_lock_locked, spin_lock_locked);
symbol_alias (__spin_lock, spin_lock);
symbol_alias (__spin_unlock, spin_unlock);
symbol_alias (__spin_try_lock, spin_try_lock);
