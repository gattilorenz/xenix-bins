#include <gnu-stabs.h>

symbol_alias (__mig_allocate, mig_allocate);
symbol_alias (__mig_deallocate, mig_deallocate);
symbol_alias (__mig_strncpy, mig_strncpy);

symbol_alias (__mig_init, mig_init);
symbol_alias (__mig_get_reply_port, mig_get_reply_port);
symbol_alias (__mig_put_reply_port, mig_put_reply_port);
symbol_alias (__mig_dealloc_reply_port, mig_dealloc_reply_port);
