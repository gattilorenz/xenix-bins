#define _EXTERN_INLINE /* Empty to define the real functions.  */
#include "spin-lock.h"
