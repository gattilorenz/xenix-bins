#include <gnu-stabs.h>

symbol_alias (__vm_page_size, vm_page_size);
