/* This file should define `struct direct' on Unix systems.
   This is the type of actual records in directory files.
   See readdir.c.  */

#error No struct dirent definition.
