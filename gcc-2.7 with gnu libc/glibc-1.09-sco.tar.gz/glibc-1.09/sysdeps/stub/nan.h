#ifndef	_NAN_H
#define	_NAN_H	1

/* This file should define `NAN' on machines that have such things.  */

#endif	/* nan.h */
