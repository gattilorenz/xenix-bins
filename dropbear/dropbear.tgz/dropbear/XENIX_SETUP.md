# Dropbear SSH on SCO Xenix 386 2.3.4 — Setup Guide

This tree is a port of [Dropbear SSH](https://matt.ucc.asn.au/dropbear/dropbear.html)
to **SCO Xenix System V/386 Release 2.3.4** built with gcc 2.5.8 and gnu make. 
It includes binaries for:

- `dropbear` — SSH2 server, with RSA/Ed25519 host keys and RSA/Ed25519 pubkey auth
- `scp` —  SCP file-transfer helper (needed for `scp`/legacy-protocol clients)

A modern OpenSSH client (tested: macOS OpenSSH, RSA-4096 client key) can be used to 
log in/transfer files.

## Installing the prebuilt binaries

Copy the include `dropbear` and `scp` binaries to `/usr/bin` (since `scp` in `/usr/local/bin`
won't work for non-interactive shells) and make sure they are executable.

Create the `/etc/dropbear` folder. Dropbear generates its own host keys on first run 
if none exist. 

Dropbear refuses pubkey auth if the user's home directory isn't privately owned. On a 
stock Xenix install, `/` (root's default home in `/etc/passwd`) is owned by `bin`, 
which fails this check. Give root a real home directory, or use another user:

```
mkdir -p /root
chown root /root
chmod 700 /root
mv /.profile /root/.profile
```
Then edit `/etc/passwd` to point root's home field at `/root` instead of `/`.

### authorized_keys

```
mkdir -p /root/.ssh
chmod 700 /root/.ssh
```

Put the client's public key into `/root/.ssh/authorized_key`

Note the filename: it's `authorized_key` (not the more canonical `authorized_keys`) since
Xenix's filesystem will truncate anything beyond 14 characters.

### Password authentication

This Xenix has no `crypt()` function anywhere on the system except statically linked
inside `/bin/login`'s own binary — nothing to link against. This tree includes a real,
public-domain DES-based `crypt(3)` implementation (`src/crypt3.c`, Michael Dipperstein,
1998) wired in specifically so password auth can work, verifying against the real
crypt hashes already in `/etc/passwd`. It's enabled by default in this build
(`DROPBEAR_SVR_PASSWORD_AUTH=1` in `src/default_opti.h`) — no extra setup needed, both
pubkey and password auth are offered.

If you ever rebuild with this disabled and want to turn it back on, you also need
`HAVE_CRYPT` defined in `config.h` (a compile-time guard checks for it) — both flags are
already set correctly in this tree.

### Starting the server

```
nohup /usr/bin/dropbear -F -p 2222 > /var/log/dropbear.log 2>&1 &
```

- `-F`: stay in the foreground (needed since there's no real init/daemon-fork support tested
  here; run it under `nohup &` or a supervising script instead)
- `-p 2222`: listen port

## Connecting from a modern client

Two dropbear-side limitations mean you need to pin some options on the client:

```
ssh -i ~/.ssh/id_rsa \
    -o KexAlgorithms=curve25519-sha256 \
    -o Ciphers=aes128-ctr \
    -p 2222 root@<host>
```

```
scp -O -i ~/.ssh/id_rsa \
    -o KexAlgorithms=curve25519-sha256 \
    -o Ciphers=aes128-ctr \
    -P 2222 \
    localfile root@<host>:/remote/path
```

- **`KexAlgorithms=curve25519-sha256`**: the generic NIST P-256/384/521 ECDH key exchange
  goes through libtomcrypt's generic bignum path and is unusably slow (multiple minutes 
  per handshake). Dropbear's dedicated Curve25519 implementation doesn't have this
  problem — pin it explicitly rather than letting negotiation pick a slow default.
- **`Ciphers=aes128-ctr`**: `chacha20-poly1305@openssh.com` corrupts packets after the
  handshake on this build. AES-CTR is unaffected.
- **`scp -O`**: modern OpenSSH clients default to the SFTP subsystem protocol for `scp`, not
  the classic SCP protocol. This build only has a classic `scp` binary (no `sftp-server`), so
  you must force the old protocol with `-O`.

## Building from source

```
cd dropbear
gmake dropbear     # builds src/, libtommath/, libtomcrypt/, links dropbear
gmake scp          # scp is not part of the default target list, build it separately
```

A full clean build takes a few minutes on emulated period hardware. If you're doing a
clean rebuild, remove stale objects and archives first:

```
find . -print | grep '\.o$' | xargs rm -f
rm -f libtommath/libtommath.a libtomcrypt/libtomcrypt.a dropbear scp
gmake dropbear
gmake scp
```

### If the link fails with unresolved externals

`gmake`'s own incremental `ar r` step for each freshly-compiled `.o` file is unreliable on
this `ar`/filesystem combination — it can silently drop an already-compiled object from the
archive. If you see unresolved externals at link time even though the corresponding `.c`
files clearly compiled without error, rebuild the archive from every `.o` file actually on
disk:

```
cd libtomcrypt
find . -print | grep '\.o$' > /tmp/objs.txt
rm -f libtomcrypt.a
for f in `cat /tmp/objs.txt`; do ar r libtomcrypt.a $f; done
ranlib libtomcrypt.a
cd ../libtommath
# repeat for libtommath.a
cd ..
gmake dropbear
```
