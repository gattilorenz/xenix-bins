/* Minimal termios.h shim for Xenix, which only has the older SVR3
 * <sys/termio.h>/TCGETA/TCSETA ioctl interface, not POSIX termios.
 *
 * termio's c_iflag/c_oflag/c_cflag/c_lflag bit values are reused directly
 * (no translation) since termio already defines ISIG/ICANON/ECHO/OPOST/
 * ONLCR/ICRNL etc identically to what dropbear needs.
 *
 * termio's 8-slot c_cc[] already covers VINTR/VQUIT/VERASE/VKILL and,
 * context-dependent on ICANON, VEOF-or-VMIN / VEOL-or-VTIME / VEOL2 /
 * VSWTCH -- so those map straight onto the same physical kernel slots.
 * VSTART/VSTOP/VSUSP have no equivalent in termio (fixed to ^Q/^S/^Z by
 * the OS, not configurable), so they're tracked here only in the
 * in-memory struct and are NOT enforced by tcsetattr -- a client asking
 * for custom flow-control/suspend characters won't get them, everything
 * else (the characters dropbear's own code actually depends on for
 * session behaviour) works correctly.
 */
#ifndef _TERMIOS_SHIM_H
#define _TERMIOS_SHIM_H

#include <sys/termio.h>
#include <sys/ioctl.h>

typedef unsigned char cc_t;
typedef unsigned short tcflag_t;
typedef unsigned int speed_t;

#undef VINTR
#undef VQUIT
#undef VERASE
#undef VKILL
#undef VEOF
#undef VEOL
#undef VEOL2
#undef VMIN
#undef VTIME
#undef VSWTCH
#define VINTR   0
#define VQUIT   1
#define VERASE  2
#define VKILL   3
#define VEOF    4
#define VMIN    4
#define VEOL    5
#define VTIME   5
#define VEOL2   6
#define VSWTCH  7

/* c_lflag bits with no termio equivalent (job control / extended input
 * processing didn't exist yet on this SVR3 target) -- picked from bit
 * positions termio's own c_lflag never uses (see sys/termio.h: ISIG=01,
 * ICANON=02, XCASE=04, ECHO=010, ECHOE=020, ECHOK=040, ECHONL=0100,
 * NOFLSH=0200, XCLUDE=0100000). Setting them is a harmless no-op when
 * passed through to the real ioctl -- the kernel just doesn't act on
 * them, same non-enforcement compromise as VSTART/VSTOP/VSUSP below. */
#ifndef TOSTOP
#define TOSTOP  0004000
#endif
#ifndef IEXTEN
#define IEXTEN  0010000
#endif
#define VSTART  8
#define VSTOP   9
#define VSUSP   10
#define NCCS    16

struct termios {
	tcflag_t c_iflag;
	tcflag_t c_oflag;
	tcflag_t c_cflag;
	tcflag_t c_lflag;
	cc_t     c_cc[NCCS];
	speed_t  c_ispeed;
	speed_t  c_ospeed;
};

#define TCSANOW   0
#define TCSADRAIN 1
#define TCSAFLUSH 2

static int tcgetattr(int fd, struct termios *t)
{
	struct termio tio;
	int i;
	if (ioctl(fd, TCGETA, &tio) < 0) return -1;
	t->c_iflag = tio.c_iflag;
	t->c_oflag = tio.c_oflag;
	t->c_cflag = tio.c_cflag;
	t->c_lflag = tio.c_lflag;
	for (i = 0; i < NCC; i++) t->c_cc[i] = tio.c_cc[i];
	t->c_cc[VSTART] = CSTART;
	t->c_cc[VSTOP] = CSTOP;
	t->c_cc[VSUSP] = CSWTCH;
	t->c_ispeed = t->c_ospeed = B9600;
	return 0;
}

static int tcsetattr(int fd, int action, struct termios *t)
{
	struct termio tio;
	int i, cmd;
	tio.c_iflag = t->c_iflag;
	tio.c_oflag = t->c_oflag;
	tio.c_cflag = t->c_cflag;
	tio.c_lflag = t->c_lflag;
	tio.c_line = 0;
	for (i = 0; i < NCC; i++) tio.c_cc[i] = t->c_cc[i];
	switch (action) {
		case TCSADRAIN: cmd = TCSETAW; break;
		case TCSAFLUSH: cmd = TCSETAF; break;
		default: cmd = TCSETA; break;
	}
	return ioctl(fd, cmd, &tio);
}

#endif /* _TERMIOS_SHIM_H */
