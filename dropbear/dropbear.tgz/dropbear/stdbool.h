/* Minimal stdbool.h shim -- Xenix predates C99, has no such header at all. */
#ifndef _STDBOOL_H
#define _STDBOOL_H

#ifndef __cplusplus
#define bool  int
#define true  1
#define false 0
#endif

#define __bool_true_false_are_defined 1

#endif /* _STDBOOL_H */
