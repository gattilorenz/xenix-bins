/*
 * Dropbear SSH
 * 
 * Copyright (c) 2002,2003 Matt Johnston
 * All rights reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. */

#ifndef DROPBEAR_COMPAT_H_
#define DROPBEAR_COMPAT_H_

#include "includes.h"

#ifndef HAVE_STRLCPY
size_t strlcpy(char *dst, const char *src, size_t size);
#endif

#ifndef HAVE_STRLCAT
size_t strlcat(char *dst, const char *src, size_t siz);
#endif

#ifndef HAVE_DAEMON
int daemon(int nochdir, int noclose);
#endif

#ifndef HAVE_BASENAME
char *basename(const char* path);
#endif

#ifndef HAVE_GETUSERSHELL
char *getusershell(void);
void setusershell(void);
void endusershell(void);
#endif

#ifndef DROPBEAR_PATH_DEVNULL
#define DROPBEAR_PATH_DEVNULL "/dev/null"
#endif

/* Xenix has none of these POSIX basics */
#ifndef _SSIZE_T_DEFINED
#define _SSIZE_T_DEFINED
typedef int ssize_t;
#endif

#ifndef _SUSECONDS_T_DEFINED
#define _SUSECONDS_T_DEFINED
typedef long suseconds_t;
#endif

/* Xenix's <time.h> bundles clock_t's typedef inside its "#ifndef _TIME_T"
 * guard alongside time_t -- but sys/types.h (included first) already
 * defines time_t and sets that same guard, so clock_t is silently never
 * defined. */
#ifndef _CLOCK_T_DEFINED
#define _CLOCK_T_DEFINED
typedef long clock_t;
#endif

/* No <sys/uio.h>/readv/writev on Xenix at all -- confirmed genuinely
 * absent, not just undetected. Minimal struct + a writev() that just
 * loops calling write() per segment; functionally correct, not truly
 * vectored, which is fine here (no fallback path exists upstream yet,
 * see netio.h's own "TODO: writev #ifdef guard"). */
#ifndef IOV_MAX
#define IOV_MAX 16
#endif
#ifndef _STRUCT_IOVEC_DEFINED
#define _STRUCT_IOVEC_DEFINED
struct iovec {
	void   *iov_base;
	size_t  iov_len;
};
#endif
static ssize_t writev(int fd, const struct iovec *iov, int iovcnt) {
	ssize_t total = 0;
	int i;
	for (i = 0; i < iovcnt; i++) {
		ssize_t n = write(fd, iov[i].iov_base, iov[i].iov_len);
		if (n < 0) {
			return total > 0 ? total : n;
		}
		total += n;
		if ((size_t)n < iov[i].iov_len) {
			break;
		}
	}
	return total;
}

/* Xenix's unistd.h declares neither read() nor write() at all -- fine for
 * a normal call (old K&R implicit-declaration is tolerated), but atomicio.h
 * takes their address directly ("(ssize_t (*)(...))write") to pass as a
 * function pointer, which needs a real declared symbol to reference. */
ssize_t read(int fd, void *buf, size_t count);
ssize_t write(int fd, const void *buf, size_t count);

/* shutdown()'s SHUT_RD/WR/RDWR constants (a later POSIX addition) aren't
 * defined on Xenix -- shutdown() itself still takes the plain 0/1/2. */
#ifndef SHUT_RD
#define SHUT_RD   0
#endif
#ifndef SHUT_WR
#define SHUT_WR   1
#endif
#ifndef SHUT_RDWR
#define SHUT_RDWR 2
#endif

/* crypt(3) does not exist as a linkable function anywhere on this Xenix --
 * confirmed absent from every /lib/386/Slib*.a and from /usr/lib. The only
 * copy on the whole system is statically linked inside /bin/login's own
 * binary (visible via nm), with no way to reuse it short of fragile binary
 * extraction. src/crypt3.c provides a real, public-domain, traditional
 * DES-based crypt(3) implementation (Michael Dipperstein, 1998, released
 * without restriction -- see the file header) so that
 * DROPBEAR_SVR_PASSWORD_AUTH can actually verify against this system's
 * genuinely DES-crypt-hashed /etc/passwd entries. */
char *crypt(char *pw, char *salt);

/* None of these BSD socket errno codes exist on Xenix at all -- confirmed
 * genuinely absent, not just undetected (checked sys/errno.h and
 * sys/socket.h directly). Highest real errno in sys/errno.h's M_I386
 * branch is EREMDEV=142, so 150+ is clear of collisions. */
#ifndef ENOSYS
#define ENOSYS 150
#endif
#ifndef EINPROGRESS
#define EINPROGRESS 151
#endif
#ifndef ENOTSOCK
#define ENOTSOCK 152
#endif
#ifndef ECONNRESET
#define ECONNRESET 153
#endif
#ifndef ECONNREFUSED
#define ECONNREFUSED 154
#endif
#ifndef ETIMEDOUT
#define ETIMEDOUT 155
#endif
#ifndef EWOULDBLOCK
#define EWOULDBLOCK EAGAIN
#endif
#ifndef ENETUNREACH
#define ENETUNREACH 156
#endif
#ifndef EHOSTUNREACH
#define EHOSTUNREACH 157
#endif
#ifndef EOPNOTSUPP
#define EOPNOTSUPP 158
#endif
#ifndef EAFNOSUPPORT
#define EAFNOSUPPORT 159
#endif

/* Xenix's sys/wait.h ships pre-POSIX BSD wait-status macros that expect a
 * "union wait" value (member access like (x).w_stopval), not a plain int
 * -- and doesn't define WEXITSTATUS/WTERMSIG/WCOREDUMP at all. Redefine
 * the whole family with the standard int-based bit layout instead. This
 * matches the same bit layout the union's own bitfields already describe
 * (w_Termsig:7, w_Coredump:1, w_Retcode:8), i.e. it's the real wait()
 * status word layout on this kernel, just accessed directly instead of
 * through the struct. */
#ifdef WIFEXITED
#undef WIFEXITED
#endif
#ifdef WIFSIGNALED
#undef WIFSIGNALED
#endif
#define WIFEXITED(status)   (((status) & 0x7f) == 0)
#define WEXITSTATUS(status) (((status) >> 8) & 0xff)
#define WIFSIGNALED(status) ((((status) & 0x7f) + 1) >> 1 > 0)
#define WTERMSIG(status)    ((status) & 0x7f)
#define WCOREDUMP(status)   ((status) & 0x80)

/* No struct sigaction/sigaction()/sigset_t at all on Xenix -- only the
 * old signal() API. Minimal shim: sa_mask/sa_flags are accepted but not
 * actually enforced (sigaction() just calls signal(), same class of
 * compromise as everywhere else in this port -- no real job control or
 * signal-blocking-during-handler semantics on this OS anyway). */
#ifndef _SIGSET_T_DEFINED
#define _SIGSET_T_DEFINED
typedef int sigset_t;
#endif
#ifndef SA_NOCLDSTOP
#define SA_NOCLDSTOP 1
#endif
struct sigaction {
	void (*sa_handler)(int);
	sigset_t sa_mask;
	int sa_flags;
};
static int sigemptyset(sigset_t *set) { *set = 0; return 0; }
static int sigaction(int signum, const struct sigaction *act, struct sigaction *oldact) {
	void (*old)(int) = signal(signum, act->sa_handler);
	if (oldact) {
		oldact->sa_handler = old;
		oldact->sa_mask = 0;
		oldact->sa_flags = 0;
	}
	return old == (void (*)(int))-1 ? -1 : 0;
}

/* Left undefined upstream (default_opti.h has it commented out, meant for
 * optional override in localoptions.h) but used as a plain runtime C
 * identifier, not just in #if, in svr-chansess.c -- "undeclared" isn't a
 * preprocessor error there, it's the C compiler seeing an unknown symbol.
 * Default matches the intended semantics (feature off unless opted in). */
#ifndef DROPBEAR_SVR_DROP_PRIVS
#define DROPBEAR_SVR_DROP_PRIVS 0
#endif

/* No job control on Xenix (predates it) -- SIGTTOU genuinely doesn't
 * exist. Highest real signal in sys/signal.h is SIGPOLL=20, so 26 is
 * clear of collisions. Raising/blocking a signal number the kernel
 * doesn't know about is a harmless no-op, same class of compromise as
 * the unenforced termio c_cc slots. */
#ifndef SIGTTOU
#define SIGTTOU 26
#endif

/* No terminal-resize ioctl at all in classic SVR3 termio -- struct
 * winsize/TIOCGWINSZ/TIOCSWINSZ are later BSD/POSIX additions. Picked
 * ioctl numbers from the 'T' ioctl type's unused range (see
 * sys/termio.h: TCGETA..TCFLSH use TIOC|1..TIOC|7, TCDSET uses TIOC|32).
 * The ioctl() call will just fail harmlessly at runtime since the
 * kernel doesn't implement it -- callers already have to handle that. */
#ifndef _STRUCT_WINSIZE_DEFINED
#define _STRUCT_WINSIZE_DEFINED
struct winsize {
	unsigned short ws_row;
	unsigned short ws_col;
	unsigned short ws_xpixel;
	unsigned short ws_ypixel;
};
#endif
#ifndef TIOCGWINSZ
#define TIOCGWINSZ (('T'<<8)|8)
#endif
#ifndef TIOCSWINSZ
#define TIOCSWINSZ (('T'<<8)|9)
#endif

/* strtoul: genuinely missing (checked stdlib.h directly). Minimal base
 * 8/10/16 implementation, no sign handling (dropbear's own usage is
 * always unsigned-looking numeric strings). */
static unsigned long strtoul(const char *nptr, char **endptr, int base) {
	unsigned long result = 0;
	while (*nptr == ' ' || *nptr == '\t') nptr++;
	if (base == 0) {
		if (nptr[0] == '0' && (nptr[1] == 'x' || nptr[1] == 'X')) { base = 16; nptr += 2; }
		else if (nptr[0] == '0') { base = 8; nptr++; }
		else base = 10;
	} else if (base == 16 && nptr[0] == '0' && (nptr[1] == 'x' || nptr[1] == 'X')) {
		nptr += 2;
	}
	for (;;) {
		int c = *nptr;
		int digit;
		if (c >= '0' && c <= '9') digit = c - '0';
		else if (c >= 'a' && c <= 'z') digit = c - 'a' + 10;
		else if (c >= 'A' && c <= 'Z') digit = c - 'A' + 10;
		else break;
		if (digit >= base) break;
		result = result * (unsigned long)base + (unsigned long)digit;
		nptr++;
	}
	if (endptr) *endptr = (char *)nptr;
	return result;
}

/* waitpid: genuinely missing, only plain blocking wait() exists (this
 * Xenix predates POSIX job control entirely, no wait3/wait4 either).
 * Two call patterns exist in this codebase:
 *  - waitpid(specific_pid, &status, 0): loop wait()ing, discarding any
 *    other child's status, until the target pid shows up.
 *  - waitpid(-1, &status, WNOHANG): reap "one exited child if any,
 *    without blocking". True non-blocking wait doesn't exist here, so
 *    emulate it with a 1-second alarm() that interrupts a blocking
 *    wait() via EINTR if nothing was ready in that window -- the
 *    call sites are only reached right after a SIGCHLD already fired,
 *    so in the common case wait() returns almost immediately and the
 *    alarm never fires; worst case adds up to ~1s latency when draining
 *    the last already-known-exited child from the loop. */
static int dropbear_waitpid_got_alarm = 0;
static void dropbear_waitpid_alarm_handler(int sig) {
	(void)sig;
	dropbear_waitpid_got_alarm = 1;
}
static int waitpid(int pid, int *status, int options) {
	int r, st;
	if (options & WNOHANG) {
		void (*old_alarm)(int);
		dropbear_waitpid_got_alarm = 0;
		old_alarm = signal(SIGALRM, dropbear_waitpid_alarm_handler);
		alarm(1);
		r = wait(&st);
		alarm(0);
		signal(SIGALRM, old_alarm);
		if (status) *status = st;
		if (r < 0 && dropbear_waitpid_got_alarm) return 0;
		return r;
	}
	for (;;) {
		r = wait(&st);
		if (status) *status = st;
		if (r < 0 || pid <= 0 || r == pid) return r;
	}
}

/* getrlimit/setrlimit: genuinely missing (this Xenix predates BSD-style
 * resource limits). Only used for RLIMIT_CORE in dbutil.c, which already
 * TRACE()-logs and continues on failure -- always-fail stubs are
 * sufficient, struct rlimit/RLIMIT_CORE themselves already exist here
 * (dbutil.c compiled fine, so those types/constants are real). */
static int getrlimit(int resource, struct rlimit *rlim) {
	(void)resource; (void)rlim;
	return -1;
}
static int setrlimit(int resource, const struct rlimit *rlim) {
	(void)resource; (void)rlim;
	return -1;
}

/* ftruncate: genuinely missing. chsize(fd, long) is declared in
 * prototypes.h and looked like the classic SysV equivalent, but it's
 * actually a DOS-runtime-ism (this system also ships a separate
 * /usr/lib/dos/* compat library tree) -- confirmed via an isolated
 * link test that it doesn't actually exist in the native libc despite
 * the declaration.
 *
 * loginrec.c's two callers (wtmp_write's failed-write cleanup path)
 * never check the return value, so those are fine regardless. scp.c
 * DOES check it (fatal on failure) -- since there's no real syscall to
 * shrink a file via an already-open fd (no fcntl(F_GETPATH) on this
 * Xenix to reopen with O_TRUNC, so a genuine shrink-by-fd isn't
 * possible here), this only actually succeeds when the requested
 * length already matches the current size (the expected case: scp.c
 * now opens its destination with O_TRUNC itself, so by the time it
 * calls ftruncate(ofd, size) after writing exactly `size` bytes, the
 * file is already the right length) or when growing (handled via the
 * classic lseek-past-EOF-then-write-one-byte sparse-extend trick). */
static int ftruncate(int fd, long length) {
	struct stat st;
	if (fstat(fd, &st) != 0) {
		return -1;
	}
	if (st.st_size == length) {
		return 0;
	}
	if (length > st.st_size) {
		off_t save = lseek(fd, 0, SEEK_CUR);
		int ok = (lseek(fd, length - 1, SEEK_SET) != (off_t)-1)
			&& (write(fd, "", 1) == 1);
		lseek(fd, save, SEEK_SET);
		return ok ? 0 : -1;
	}
	/* shrink-by-fd genuinely not possible here */
	return -1;
}

/* inet_aton: genuinely missing, but inet_addr() (older, no way to
 * distinguish "invalid" from the literal address 255.255.255.255) does
 * exist and covers the same job for our purposes. */
static int inet_aton(const char *cp, struct in_addr *inp) {
	unsigned long addr = inet_addr(cp);
	if (addr == (unsigned long)-1) return 0;
	inp->s_addr = addr;
	return 1;
}

/* fsync: genuinely missing, no per-fd sync primitive on this Xenix at
 * all -- sync() (whole-filesystem, always succeeds) is the closest
 * available thing. */
static int fsync(int fd) {
	(void)fd;
	sync();
	return 0;
}

/* seteuid/setegid: genuinely missing (this Xenix predates the
 * real-vs-effective id distinction in its syscall set) -- setuid/setgid
 * do exist and change both real+effective at once. Loses the ability to
 * switch back to a higher-privileged id afterward, which matters for
 * dropbear's temporary-privilege-drop-then-restore pattern in
 * svr-agentfwd.c -- a real, disclosed limitation on this target, not
 * fully equivalent, but the closest available primitive. */
static int seteuid(int uid) { return setuid(uid); }
static int setegid(int gid) { return setgid(gid); }

/* setsid: genuinely missing (POSIX session API, predates this Xenix).
 * The classic pre-POSIX setpgrp() (no args) is confirmed to both exist
 * and link here, and sets the caller as a new process group leader in
 * one call the same way old SysV rolled process-group and session
 * leadership together before POSIX split them apart -- close enough for
 * this port's daemonisation/pty-session-leader use sites. */
static int setsid(void) { return setpgrp(); }

/* initgroups/getgroups: genuinely missing, no supplementary-group support
 * on this Xenix at all. initgroups() no-ops (setgid(), already called by
 * its one caller right before, covers the primary group -- the best
 * available on this target). getgroups() specifically returns -1/ENOSYS
 * rather than a plain "no groups" success: common-sessi.c has a
 * DROPBEAR_SVR_MULTIUSER=0 (this build's default) sanity check that
 * requires exactly that errno to confirm "non-multiuser kernel" before
 * proceeding -- ENOSYS is also the honest answer here regardless, since
 * the syscall really doesn't exist on this system. */
static int initgroups(const char *user, int gid) {
	(void)user; (void)gid;
	return 0;
}
static int getgroups(int gidsetsize, int *grouplist) {
	(void)gidsetsize; (void)grouplist;
	errno = ENOSYS;
	return -1;
}

/* strftime: declared in time.h but genuinely absent as a linkable
 * symbol. Only one call site in this codebase, with a fixed format
 * string ("%b %d %H:%M:%S") -- minimal implementation covering just
 * those specifiers rather than a general strftime. */
static size_t strftime(char *s, size_t max, char *format, struct tm *tm) {
	static const char *months[] = {
		"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"
	};
	char buf[64];
	char *p = buf;
	const char *f = format;
	(void)max;
	while (*f) {
		if (*f == '%' && f[1]) {
			f++;
			switch (*f) {
				case 'b': p += sprintf(p, "%s", months[tm->tm_mon % 12]); break;
				case 'd': p += sprintf(p, "%02d", tm->tm_mday); break;
				case 'H': p += sprintf(p, "%02d", tm->tm_hour); break;
				case 'M': p += sprintf(p, "%02d", tm->tm_min); break;
				case 'S': p += sprintf(p, "%02d", tm->tm_sec); break;
				default: *p++ = *f; break;
			}
			f++;
		} else {
			*p++ = *f++;
		}
	}
	*p = '\0';
	strcpy(s, buf);
	return (size_t)(p - buf);
}

/* memmove/strncasecmp/snprintf/vsnprintf are all genuinely absent from
 * this Xenix's libc (checked string.h directly, and confirmed via
 * undefined-symbol link errors against a real, complete build -- these
 * aren't a missing -l flag, unlike the socket family below). vsprintf
 * itself does exist (old K&R-style empty-paren prototype), used here as
 * the snprintf/vsnprintf building block. */
static void *memmove(void *dest, const void *src, size_t n) {
	unsigned char *d = (unsigned char *)dest;
	const unsigned char *s = (const unsigned char *)src;
	if (d < s) {
		while (n--) *d++ = *s++;
	} else if (d > s) {
		d += n; s += n;
		while (n--) *--d = *--s;
	}
	return dest;
}
static int strncasecmp(const char *s1, const char *s2, size_t n) {
	while (n && *s1 && *s2) {
		int c1 = *s1, c2 = *s2;
		if (c1 >= 'A' && c1 <= 'Z') c1 += 'a' - 'A';
		if (c2 >= 'A' && c2 <= 'Z') c2 += 'a' - 'A';
		if (c1 != c2) return c1 - c2;
		s1++; s2++; n--;
	}
	return n == 0 ? 0 : (unsigned char)*s1 - (unsigned char)*s2;
}
/* Not reentrant/thread-safe (static buffer) -- fine here, this port has
 * no threads and no async-signal-context snprintf calls. */
static int vsnprintf(char *str, size_t size, const char *format, va_list ap) {
	static char buf[4096];
	int n = vsprintf(buf, format, ap);
	if (size > 0) {
		size_t copy = (size_t)n < size ? (size_t)n : size - 1;
		memcpy(str, buf, copy);
		str[copy] = '\0';
	}
	return n;
}
static int snprintf(char *str, size_t size, const char *format, ...) {
	va_list ap;
	int n;
	va_start(ap, format);
	n = vsnprintf(str, size, format, ap);
	va_end(ap);
	return n;
}

/* scp.c support: this 1988 SysV.2 Xenix predates several BSD/POSIX.1
 * additions it relies on for local file handling (only reached when scp
 * is used to build/read files locally, e.g. as the passive remote-side
 * "-t"/"-f" endpoint a real client's `scp` execs over the SSH session --
 * never the network/hostname-resolution code paths). */

/* S_IFMT/S_IFDIR/S_IFREG exist in sys/stat.h, just not the S_ISxxx(m)
 * convenience macros built on top of them. */
#ifndef S_ISDIR
#define S_ISDIR(m) (((m) & S_IFMT) == S_IFDIR)
#endif
#ifndef S_ISREG
#define S_ISREG(m) (((m) & S_IFMT) == S_IFREG)
#endif

/* gettimeofday() is a BSD-ism, genuinely absent -- only second resolution
 * is available here (time()), which is fine for scp's progress meter and
 * transfer-rate estimate (not used for anything correctness-critical). */
static int gettimeofday(struct timeval *tv, void *tz) {
	(void)tz;
	tv->tv_sec = time(NULL);
	tv->tv_usec = 0;
	return 0;
}

/* utimes() is a BSD-ism; the underlying syscall on this Xenix is the
 * classic SysV utime(2), taking a raw time_t[2] {atime, mtime} rather
 * than struct utimbuf or struct timeval[2] -- and even that has no
 * prototype in any shipped header (only the .o symbol exists in
 * Slibc.a), so declare it ourselves. */
extern int utime(const char *path, const time_t times[2]);
static int utimes(const char *path, const struct timeval times[2]) {
	time_t t[2];
	t[0] = times[0].tv_sec;
	t[1] = times[1].tv_sec;
	return utime(path, t);
}

/* vasprintf() is a GNU/BSD-ism, built here on top of the vsnprintf()
 * shim above (which already has to render into its own internal buffer
 * first, so just reuse that rather than duplicating vsprintf logic). */
static int vasprintf(char **strp, const char *format, va_list ap) {
	char probe[4096];
	int n = vsnprintf(probe, sizeof(probe), format, ap);
	if (n < 0) {
		*strp = NULL;
		return -1;
	}
	*strp = malloc((size_t)n + 1);
	if (*strp == NULL) {
		return -1;
	}
	memcpy(*strp, probe, (size_t)n + 1);
	return n;
}

/* Xenix has no <fnmatch.h>/fnmatch() at all -- used by scp.c only to check
 * a received filename against the glob pattern(s) the local side asked
 * for (e.g. `scp remote:'foo*' local/`). Minimal glob-only implementation
 * (`*`, `?`, `[...]` character classes); FNM_* flags are unused by scp.c
 * so ignored here. */
static int fnmatch(const char *pattern, const char *string, int flags) {
	(void)flags;
	for (;;) {
		char pc = *pattern;
		if (pc == '\0') {
			return *string == '\0' ? 0 : 1;
		}
		if (pc == '*') {
			while (*pattern == '*') pattern++;
			if (*pattern == '\0') return 0;
			for (; *string != '\0'; string++) {
				if (fnmatch(pattern, string, flags) == 0) return 0;
			}
			return 1;
		}
		if (*string == '\0') return 1;
		if (pc == '?') {
			pattern++; string++;
			continue;
		}
		if (pc == '[') {
			const char *p = pattern + 1;
			int neg = 0, matched = 0;
			char sc = *string;
			if (*p == '!' || *p == '^') { neg = 1; p++; }
			while (*p != ']' && *p != '\0') {
				if (p[1] == '-' && p[2] != ']' && p[2] != '\0') {
					if (sc >= p[0] && sc <= p[2]) matched = 1;
					p += 3;
				} else {
					if (sc == *p) matched = 1;
					p++;
				}
			}
			if (*p == ']') p++;
			if (matched == neg) return 1;
			pattern = p; string++;
			continue;
		}
		if (pc != *string) return 1;
		pattern++; string++;
	}
}

/* Xenix's own <string.h> ships a broken strerror() macro with a stray
 * trailing ';' baked into its body ("#define strerror(err) (
 * sys_errlist[err] );") -- breaks any call embedded in a larger
 * expression, e.g. as an argument to another function. */
#ifdef strerror
#undef strerror
#endif
#define strerror(err) (sys_errlist[err])

/* No clock_gettime()/POSIX realtime clocks on this Xenix at all (predates
 * POSIX.1b) -- gettime_wrapper() falls back to gettimeofday() regardless,
 * it just needs the struct to exist. */
#ifndef _STRUCT_TIMESPEC_DEFINED
#define _STRUCT_TIMESPEC_DEFINED
struct timespec {
	time_t tv_sec;
	long   tv_nsec;
};
#endif

/* nanosleep: genuinely missing (POSIX.1b, predates this Xenix). Emulate
 * via select() with a computed timeout -- the standard portable trick.
 * Uses the same struct timespec shimmed just above, not a separate type,
 * since real call sites (e.g. svr-auth.c) declare their variables as
 * plain "struct timespec". */
static int nanosleep(const struct timespec *req, struct timespec *rem) {
	struct timeval tv;
	tv.tv_sec = req->tv_sec;
	tv.tv_usec = req->tv_nsec / 1000;
	(void)rem;
	return select(0, NULL, NULL, NULL, &tv);
}

#ifndef SIGCHLD
#define SIGCHLD SIGCLD
#endif

#ifndef STDIN_FILENO
#define STDIN_FILENO 0
#endif
#ifndef STDOUT_FILENO
#define STDOUT_FILENO 1
#endif
#ifndef STDERR_FILENO
#define STDERR_FILENO 2
#endif

#ifndef O_NONBLOCK
#define O_NONBLOCK O_NDELAY
#endif

#if !(defined(HAVE_HTOLE64) || defined(HAVE_DECL_HTOLE64))

uint64_t htole64(uint64_t inp);
uint64_t le64toh(uint64_t inp);
uint32_t htole32(uint32_t inp);
uint32_t le32toh(uint32_t inp);

#endif /* HAVE_HTOLE64 */

#endif /* DROPBEAR_COMPAT_H_ */
