#ifndef DROPBEAR_DBHELPERS_H_
#define DROPBEAR_DBHELPERS_H_

/* This header defines some things that are also used by libtomcrypt/math. 
   We avoid including normal include.h since that can result in conflicting 
   definitions - only include config.h */
#include "config.h"

/* gcc 2.5.8 (this Xenix target) can't parse two chained __attribute__(())
   specifiers on one declaration (e.g. ATTRIB_PRINTF(...) ATTRIB_NORETURN,
   used throughout this codebase) -- "parse error before `__attribute__'".
   Require a newer-looking GCC before using attributes at all; 2.5.8 falls
   through to the plain #else below same as a non-GNU compiler would. */
#if defined(__GNUC__) && (__GNUC__ > 2 || (__GNUC__ == 2 && __GNUC_MINOR__ >= 7))
#define ATTRIB_PRINTF(fmt,args) __attribute__((format(printf, fmt, args)))
#define ATTRIB_NORETURN __attribute__((noreturn))
#define ATTRIB_SENTINEL __attribute__((sentinel))
#else
#define ATTRIB_PRINTF(fmt,args)
#define ATTRIB_NORETURN
#define ATTRIB_SENTINEL
#endif

void m_burn(void* data, unsigned int len);

#endif /* DROPBEAR_DBHELPERS_H_ */
